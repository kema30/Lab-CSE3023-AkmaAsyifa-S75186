<%-- 
    Document   : processBMI
    Created on : 21 Apr 2026, 3:37:32 pm
    Author     : akmaa
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%
    String wStr = request.getParameter("weight");
    String hStr = request.getParameter("height");

    try {
        double weight = Double.parseDouble(wStr);
        double height = Double.parseDouble(hStr);

        // Validation: Height must not be zero
        if (height > 0) {
            double bmi = weight / (height * height);
            
            String category;
            if (bmi < 18.5) {
                category = "Underweight";
            } else if (bmi <= 25) {
                category = "Normal";
            } else {
                category = "Overweight";
            }
%>
            <%-- Standard Actions for data passing --%>
            <jsp:forward page="resultBMI.jsp">
                <jsp:param name="bmiValue" value="<%= String.valueOf(bmi) %>" />
                <jsp:param name="category" value="<%= category %>" />
            </jsp:forward>
<%
        } else {
            out.println("<script>alert('Height must be greater than zero'); window.location='bmiCalculator.jsp';</script>");
        }
    } catch (Exception e) {
        out.println("<script>alert('Please enter valid numeric values'); window.location='bmiCalculator.jsp';</script>");
    }
%>
