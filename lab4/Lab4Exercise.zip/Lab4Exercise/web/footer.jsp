<%-- 
    Document   : footer
    Created on : 21 Apr 2026, 3:31:36 pm
    Author     : akmaa
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Footer Page</title>
    </head>
    <body>
        <div style="text-align: center; margin-top: 40px; color: #888; font-size: 0.9rem;">
            <p>&copy; 2026 Faculty of Computer Science and Mathematics, UMT</p>
        </div>
    </body>
</html>
