<%-- 
    Document   : bmiCalculator
    Created on : 21 Apr 2026, 3:32:45 pm
    Author     : akmaa
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>BMI Calculator Page</title>
    </head>
    <body>
        <%@ include file="header.jsp" %>
        <div class="card">
            <h2 class="form-title">BMI Calculator</h2>
            <form action="processBMI.jsp" method="post">
                <div class="form-group">
                    <label>Weight (kg)</label>
                    <input type="number" step="0.01" name="weight" required>
                </div>
        
                <div class="form-group">
                    <label>Height (m)</label>
                    <input type="number" step="0.01" name="height" required>
                </div>

                <div class="button-group">
                    <button type="submit" class="btn-back">Calculate BMI</button>
                    <button type="reset" class="btn btn-cancel">Clear</button>
                </div>
            </form>
        </div>
        <%@ include file="footer.jsp" %>
    </body>
</html>
