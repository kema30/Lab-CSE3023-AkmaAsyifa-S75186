<%-- 
    Document   : healthInfo
    Created on : 21 Apr 2026, 3:41:20 pm
    Author     : akmaa
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<%@ include file="header.jsp" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <div class="card">
            <h2 class="form-title">Health Categories</h2>
            <table style="width: 100%; border-collapse: collapse;">
                <tr style="background: #6f42c1; color: white;">
                    <th style="padding: 10px; text-align: left;">Category</th>
                    <th style="padding: 10px; text-align: left;">Range</th>
                </tr>
                <%
                    ArrayList<String[]> info = new ArrayList<>();
                    info.add(new String[]{"Underweight", "Below 18.5"});
                    info.add(new String[]{"Normal", "18.5 to 25.0"});
                    info.add(new String[]{"Overweight", "Above 25.0"});

                    for(String[] row : info) {
                %>
                    <tr style="border-bottom: 1px solid #eee;">
                        <td style="padding: 10px;"><%= row[0] %></td>
                        <td style="padding: 10px;"><%= row[1] %></td>
                    </tr>
                <% } %>
            </table>
        </div>
        <%@ include file="footer.jsp" %>
    </body>
</html>
