<%-- 
    Document   : resultBMI
    Created on : 21 Apr 2026, 3:38:21 pm
    Author     : akmaa
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%@ include file="header.jsp" %>
        <div class="card">
            <h2 class="form-title">Result Assessment</h2>
    
            <div class="result-grid">
                <div class="result-box">
                    <h3>BMI Score</h3>
                        <div class="result-group-flex">
                            <%-- JSP Expression & Formatting to 2 decimal places --%>
                            <p style="font-size: 2rem; color: #6f42c1;">
                                <%= String.format("%.2f", Double.parseDouble(request.getParameter("bmiValue"))) %>
                            </p>
                        </div>
                </div>

                <div class="result-box">
                    <h3>Category</h3>
                        <div class="result-group-flex">
                            <p><strong><%= request.getParameter("category") %></strong></p>
                        </div>
                </div>
            </div>

            <div class="button-group">
                <a href="bmiCalculator.jsp" class="btn-back" style="text-decoration:none;">Back to Calculator</a>
            </div>
        </div>
        <%@ include file="footer.jsp" %>
    </body>
</html>
