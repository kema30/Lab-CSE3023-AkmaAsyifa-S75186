<%-- 
    Document   : header
    Created on : 21 Apr 2026, 3:27:58 pm
    Author     : akmaa
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Healthy Lifestyle Awareness</title>
        
        <link rel="stylesheet" type="text/css" href="style.css">
        
    </head>
    <body>
        <div class="container">
            <h1>Healthy Lifestyle Awareness Program</h1>
            <nav style="margin-bottom: 20px;">
                <a href="bmiCalculator.jsp">BMI Calculator</a> | 
                <a href="healthInfo.jsp">Health Information</a>
            </nav>
        </div>
    </body>
</html>
